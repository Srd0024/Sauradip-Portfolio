import React from 'react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 sm:py-24 px-4 sm:px-8 max-w-7xl mx-auto">
      
      {/* Huge Lowercase Heading: "about." */}
      <div className="mb-10 sm:mb-12">
        <h2 className="font-heading font-black text-6xl sm:text-7xl md:text-8xl text-[#111111] tracking-tight lowercase">
          about.
        </h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center">
        
        {/* Left Column: 3 Bio Paragraphs */}
        <div className="lg:col-span-7 space-y-6 text-neutral-800 font-sans text-sm sm:text-base md:text-[17px] leading-relaxed">
          <p>
            Call me Helmi, I am a fresh graduate with a passion for creating business strategies, marketing strategies, growth marketing, and other business or brand activities.{' '}
            <span className="underline decoration-[#111111] decoration-1.5 underline-offset-4 font-semibold">
              With 2 years of professional experience
            </span>
            , I honed my skills in business development and strategy, B2B and B2C strategy, brand strategy, data analyst, and relationship.
          </p>

          <p>
            I am experienced in social media strategy, brand strategy, marketing, campaign strategic, Ads Performance and relationship holds in various industries and companies such as FMCG., E-commerce, and Financial Technology (Fintech) company.
          </p>

          <p>
            I am deeply committed to transforming ideas into results, whether it's crafting marketing and business strategies, brand campaigns, and optimizing sales performance.
          </p>
        </div>

        {/* Right Column: Photo with Orange Semicircle Backdrop */}
        <div className="lg:col-span-5 flex justify-center relative">
          <div className="relative flex items-end justify-center w-full max-w-[360px] h-[340px] sm:h-[400px]">
            
            {/* Orange semicircle shape behind him */}
            <div className="absolute bottom-0 w-[270px] sm:w-[320px] h-[190px] sm:h-[230px] bg-gradient-to-t from-[#F5A461] to-[#F7B074] rounded-t-full -z-1 opacity-95 shadow-sm" />

            {/* Cutout Photo of Helmi in light blue button-down shirt */}
            <div className="relative w-64 sm:w-72 h-auto flex items-end justify-center z-10">
              <img
                src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=800&auto=format&fit=crop"
                alt="Helmi - About Photo"
                className="w-full h-auto object-cover object-top rounded-t-full drop-shadow-xl"
                style={{
                  maskImage: 'linear-gradient(to bottom, black 85%, transparent 100%)',
                  WebkitMaskImage: 'linear-gradient(to bottom, black 85%, transparent 100%)'
                }}
              />
            </div>

          </div>
        </div>

      </div>

    </section>
  );
};
