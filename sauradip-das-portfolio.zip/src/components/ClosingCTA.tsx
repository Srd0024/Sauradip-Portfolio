import React, { useState } from 'react';
import { Mail, Linkedin, Instagram, Twitter, Copy, Check, Send, Sparkles, Heart, ArrowUp } from 'lucide-react';

interface ClosingCTAProps {
  isContactModalOpen?: boolean;
  onCloseContactModal?: () => void;
}

export const ClosingCTA: React.FC<ClosingCTAProps> = () => {
  const [copied, setCopied] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const email = "srdofficial24@gmail.com";

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
    }, 4000);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="contact" className="w-full bg-[#FAF7F2] border-t border-neutral-300">
      
      {/* Big Closing CTA Section */}
      <div className="max-w-5xl mx-auto py-24 sm:py-32 px-4 sm:px-8 text-center flex flex-col items-center">
        
        {/* Friendly Emoji / Badge */}
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-[#FDE8D7] border-2 border-[#E8874A]/40 flex items-center justify-center text-3xl sm:text-4xl shadow-md mb-6 animate-bounce">
          👋
        </div>

        {/* Large "thank you!" heading */}
        <h2 className="font-heading font-extrabold text-5xl sm:text-7xl md:text-8xl text-[#111111] tracking-tight lowercase mb-4">
          thank you<span className="text-[#E8874A]">!</span>
        </h2>

        {/* "Looking forward to working with you" subtext */}
        <p className="font-heading font-bold text-xl sm:text-2xl md:text-3xl text-neutral-700 max-w-2xl leading-snug mb-8">
          Looking forward to working with you<span className="text-[#E8874A]">.</span>
        </p>

        <p className="font-body text-sm sm:text-base text-neutral-600 max-w-lg mb-10 leading-relaxed">
          Whether you're scaling a high-growth venture, redesigning a complex digital product, or seeking a growth design advisor, let's craft something remarkable.
        </p>

        {/* Primary Email Pill with 1-Click Copy */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
          <button
            onClick={handleCopyEmail}
            className="px-6 py-3.5 rounded-full bg-[#111111] text-white font-bold text-sm sm:text-base hover:bg-[#E8874A] transition-all flex items-center gap-2.5 shadow-md cursor-pointer"
          >
            <Mail className="w-4 h-4 text-[#F5A461]" />
            <span>{email}</span>
            <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full text-neutral-300 ml-1">
              {copied ? 'Copied!' : 'Copy'}
            </span>
          </button>

          <a
            href={`mailto:${email}?subject=Project%20Inquiry%20from%20Portfolio`}
            className="px-6 py-3.5 rounded-full border-2 border-[#111111] text-[#111111] font-bold text-sm sm:text-base hover:bg-[#111111] hover:text-white transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>Send Email ↗</span>
          </a>
        </div>

        {/* Row of Contact Icons / Links: LinkedIn, Instagram/TikTok, Email */}
        <div className="flex items-center gap-4 mb-16">
          <a
            href="https://linkedin.com"
            target="_blank"
            rel="noreferrer"
            className="w-12 h-12 rounded-full bg-white border border-neutral-300 flex items-center justify-center text-neutral-800 hover:text-[#E8874A] hover:border-[#E8874A] hover:scale-110 transition-all shadow-xs"
            aria-label="LinkedIn Profile"
          >
            <Linkedin className="w-5 h-5" />
          </a>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="w-12 h-12 rounded-full bg-white border border-neutral-300 flex items-center justify-center text-neutral-800 hover:text-[#E8874A] hover:border-[#E8874A] hover:scale-110 transition-all shadow-xs"
            aria-label="Instagram or TikTok"
          >
            <Instagram className="w-5 h-5" />
          </a>
          <a
            href="https://twitter.com"
            target="_blank"
            rel="noreferrer"
            className="w-12 h-12 rounded-full bg-white border border-neutral-300 flex items-center justify-center text-neutral-800 hover:text-[#E8874A] hover:border-[#E8874A] hover:scale-110 transition-all shadow-xs"
            aria-label="Twitter / X Profile"
          >
            <Twitter className="w-5 h-5" />
          </a>
        </div>

        {/* Interactive Quick Note Form */}
        <div className="w-full max-w-lg bg-white p-6 sm:p-8 rounded-[30px] border border-neutral-200/90 shadow-editorial text-left">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-heading font-extrabold text-lg text-[#111111]">
              Send a quick message
            </h4>
            <span className="text-[10px] font-mono text-neutral-400 bg-neutral-100 px-2 py-0.5 rounded-full">
              Instant Response
            </span>
          </div>

          {formSubmitted ? (
            <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-200 text-center">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center mb-2">
                <Check className="w-5 h-5" />
              </div>
              <p className="font-heading font-extrabold text-sm text-emerald-900">Message Dispatched!</p>
              <p className="text-xs text-emerald-700 mt-1">Thank you for reaching out. Helmi will get back to you within 24 hours.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500 mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex Miller"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FAF7F2] border border-neutral-300 text-sm text-neutral-800 focus:outline-none focus:border-[#E8874A]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  placeholder="alex@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FAF7F2] border border-neutral-300 text-sm text-neutral-800 focus:outline-none focus:border-[#E8874A]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-500 mb-1">
                  Project Brief or Question
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Tell me about your product, timeline, or scope..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#FAF7F2] border border-neutral-300 text-sm text-neutral-800 focus:outline-none focus:border-[#E8874A]"
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-[#111111] hover:bg-[#E8874A] text-white rounded-xl font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Transmit Message</span>
              </button>
            </form>
          )}
        </div>

      </div>

      {/* Simple dark footer bar with location and copyright */}
      <div className="w-full bg-[#0A0A0A] text-white py-8 px-4 sm:px-8 border-t border-neutral-900">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#F5A461]" />
            <span>Based in Jakarta, Indonesia • Remote Worldwide</span>
          </div>

          <div className="flex items-center gap-6">
            <span>© {new Date().getFullYear()} Muhammad Helmi. All rights reserved.</span>
            <button
              onClick={scrollToTop}
              className="hover:text-white flex items-center gap-1 cursor-pointer transition-colors"
              title="Scroll to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

    </footer>
  );
};
