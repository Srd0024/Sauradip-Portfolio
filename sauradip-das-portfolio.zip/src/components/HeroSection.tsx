import React, { useState, useEffect } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { HELMI_HERO } from '../data/portfolioData';

interface HeroSectionProps {
  onPortfolioClick: () => void;
  onHireMeClick: () => void;
}

// Multilingual cycling greetings exactly matching the attached video:
// 00:00 "Hello!" -> 00:01 "Horas" -> 00:02 "Ciao" -> 00:03 "नमस्ते" -> 00:04 "你好" -> 00:05 "Hello!" -> 00:06 "Hola" -> 00:07 "Bonjour"
const VIDEO_GREETINGS = [
  "Hello!",
  "Horas",
  "Ciao",
  "नमस्ते",
  "你好",
  "Hello!",
  "Hola",
  "Bonjour"
];

export const HeroSection: React.FC<HeroSectionProps> = ({ onPortfolioClick, onHireMeClick }) => {
  const [greetingIndex, setGreetingIndex] = useState(0);

  // Cycle through greetings every 1.3s just like in the video
  useEffect(() => {
    const timer = setInterval(() => {
      setGreetingIndex((prev) => (prev + 1) % VIDEO_GREETINGS.length);
    }, 1300);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="hero" className="relative pt-12 sm:pt-16 md:pt-20 pb-12 px-4 sm:px-8 max-w-7xl mx-auto flex flex-col items-center text-center overflow-hidden">
      
      {/* 1. Top Cycling Multilingual Greeting Pill + 3 Orange Radiating Doodles */}
      <div className="relative inline-flex flex-col items-center mb-5 sm:mb-6">
        {/* 3 Curved orange doodle lines radiating above the pill */}
        <svg
          viewBox="0 0 60 20"
          fill="none"
          className="w-14 h-5 text-[#F5A461] mb-1.5 stroke-current stroke-[2.5] stroke-linecap-round pointer-events-none"
        >
          {/* Left curved stroke */}
          <path d="M16 16C15 10 11 5 6 3" />
          {/* Center vertical stroke */}
          <path d="M30 16L30 3" />
          {/* Right curved stroke */}
          <path d="M44 16C45 10 49 5 54 3" />
        </svg>

        {/* The Greeting Pill with smooth text transition */}
        <div className="min-w-[100px] sm:min-w-[110px] h-7 sm:h-8 px-5 rounded-full border border-neutral-300/90 bg-white/90 backdrop-blur-xs text-xs sm:text-[13px] font-semibold text-neutral-800 tracking-wide shadow-2xs flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.span
              key={VIDEO_GREETINGS[greetingIndex]}
              initial={{ opacity: 0, y: 4, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.96 }}
              transition={{ duration: 0.22, ease: "easeInOut" }}
              className="inline-block"
            >
              {VIDEO_GREETINGS[greetingIndex]}
            </motion.span>
          </AnimatePresence>
        </div>
      </div>

      {/* 2. Headline: "I'm Sauradip 🖐️," + "A Brand & Marketing Specialist" */}
      <div className="relative mb-6 sm:mb-8 max-w-4xl mx-auto">
        
        {/* Line 1: "I'm Sauradip 🖐️," */}
        <div className="relative inline-flex items-center justify-center flex-wrap gap-x-2.5">
          <h1 className="font-heading font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-[#111111] tracking-tight leading-none inline-flex items-center">
            <span>I'm </span>
            <span className="text-[#F5A461] ml-2">Sauradip</span>
          </h1>

          {/* Waving Hand with 3 orange radiating doodle rays above it */}
          <div className="relative inline-flex items-center">
            {/* 3 Radiating Orange Doodle Rays above the hand */}
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 pointer-events-none">
              <svg
                viewBox="0 0 32 18"
                fill="none"
                className="w-7 h-3.5 text-[#F5A461] stroke-current stroke-[2.5] stroke-linecap-round"
              >
                <path d="M6 14L2 4" />
                <path d="M16 14L16 2" />
                <path d="M26 14L30 4" />
              </svg>
            </div>

            {/* Hand Emoji with subtle waving animation */}
            <span className="text-3xl sm:text-5xl md:text-6xl inline-block origin-bottom-right animate-wave select-none ml-1">
              🖐️
            </span>
            <span className="font-heading font-black text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-[#111111] leading-none">
              ,
            </span>
          </div>
        </div>

        {/* Line 2: "A Brand & Marketing Specialist" */}
        <div className="relative mt-1 sm:mt-2">
          {/* Two small diagonal orange doodle strokes '//' under 'A Brand' on the left */}
          <div className="absolute -left-6 sm:-left-8 top-1 hidden sm:block pointer-events-none">
            <svg
              viewBox="0 0 28 28"
              fill="none"
              className="w-6 h-6 text-[#F5A461] stroke-current stroke-[2.5] stroke-linecap-round"
            >
              <path d="M6 22L16 6" />
              <path d="M14 22L24 6" />
            </svg>
          </div>

          <h2 className="font-heading font-black text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-[#111111] tracking-tight leading-tight">
            {HELMI_HERO.role}
          </h2>
        </div>
      </div>

      {/* 3. Center Portrait Stage + Floating Badges + Left Pull-Quote + Right Metric */}
      <div className="relative w-full max-w-4xl my-2 sm:my-6 flex items-center justify-center min-h-[380px] sm:min-h-[460px]">
        
        {/* Left Side: Pull-Quote */}
        <div className="hidden lg:flex flex-col items-start text-left max-w-[210px] xl:max-w-[230px] absolute left-2 xl:left-4 top-1/2 -translate-y-1/2 p-2">
          <span className="text-4xl font-serif text-[#111111] leading-none mb-1 select-none font-bold">“</span>
          <p className="text-xs sm:text-[13px] leading-relaxed font-medium text-neutral-700">
            {HELMI_HERO.quote}
          </p>
        </div>

        {/* Center Portrait with Soft-Orange Semicircle / Arch */}
        <div className="relative flex flex-col items-center justify-end">
          
          {/* Soft-Orange Semicircle / Arch Shape */}
          <div className="absolute bottom-5 w-[280px] sm:w-[350px] md:w-[390px] h-[210px] sm:h-[260px] md:h-[285px] bg-[#F5A461] rounded-t-full -z-1 opacity-95 shadow-sm" />

          {/* Portrait Cutout */}
          <div className="relative w-64 sm:w-76 md:w-84 h-76 sm:h-92 md:h-98 flex items-end justify-center overflow-visible">
            <img
              src={HELMI_HERO.heroPhoto}
              alt="Sauradip - Brand & Marketing Specialist"
              className="w-56 sm:w-68 md:w-76 h-auto object-cover object-top rounded-t-full drop-shadow-2xl z-10"
              style={{
                maskImage: 'linear-gradient(to bottom, black 85%, transparent 100%)',
                WebkitMaskImage: 'linear-gradient(to bottom, black 85%, transparent 100%)'
              }}
            />
          </div>

          {/* 4 Floating Black Badges exactly matching the video */}
          {/* 1. Top-Left: [ 📣 Marketing ] */}
          <div className="absolute top-10 -left-2 sm:-left-6 z-20 px-3.5 py-1.5 rounded-full bg-[#111111] text-white text-xs font-bold shadow-lg flex items-center gap-1.5 animate-float-1 cursor-default">
            <span>📣</span>
            <span>Marketing</span>
          </div>

          {/* 2. Mid-Left: [ ⭐ Brand ] */}
          <div className="absolute bottom-28 -left-6 sm:-left-10 z-20 px-3.5 py-1.5 rounded-full bg-[#111111] text-white text-xs font-bold shadow-lg flex items-center gap-1.5 animate-float-2 cursor-default">
            <span>⭐</span>
            <span>Brand</span>
          </div>

          {/* 3. Top-Right: [ 🚀 Ads ] */}
          <div className="absolute top-16 -right-2 sm:-right-6 z-20 px-3.5 py-1.5 rounded-full bg-[#111111] text-white text-xs font-bold shadow-lg flex items-center gap-1.5 animate-float-3 cursor-default">
            <span>🚀</span>
            <span>Ads</span>
          </div>

          {/* 4. Bottom-Right: [ 🖋️ Social Media ] */}
          <div className="absolute bottom-20 -right-6 sm:-right-10 z-20 px-3.5 py-1.5 rounded-full bg-[#111111] text-white text-xs font-bold shadow-lg flex items-center gap-1.5 animate-float-4 cursor-default">
            <span>🖋️</span>
            <span>Social Media</span>
          </div>

          {/* Center Bottom: Dual Capsule Action Button [ Portfolio ↗ | Hire me ] */}
          <div className="z-30 -mt-6 sm:-mt-8 inline-flex items-center p-1 rounded-full bg-[#1E1E1E] text-white shadow-xl border border-neutral-800">
            <button
              onClick={onPortfolioClick}
              className="px-5 py-2 rounded-full bg-[#D86D2C] hover:bg-[#C25D20] text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
            >
              <span>Portfolio</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onHireMeClick}
              className="px-5 py-2 text-xs sm:text-sm font-bold text-neutral-300 hover:text-white transition-colors cursor-pointer"
            >
              Hire me
            </button>
          </div>

        </div>

        {/* Right Side: Stat Callout */}
        <div className="hidden lg:flex flex-col items-start text-left max-w-[210px] xl:max-w-[230px] absolute right-2 xl:right-4 top-1/2 -translate-y-1/2 p-2">
          <div className="font-heading font-black text-3xl xl:text-4xl text-[#111111] leading-none mb-1">
            {HELMI_HERO.experienceYears}
          </div>
          <p className="text-xs text-neutral-600 font-medium leading-tight">
            {HELMI_HERO.experienceSubtext}
          </p>
        </div>

      </div>

      {/* Mobile Quote & Stat View for responsive screens */}
      <div className="lg:hidden w-full max-w-sm mt-6 grid grid-cols-2 gap-3 text-left">
        <div className="p-3 bg-white rounded-2xl border border-neutral-200 shadow-2xs">
          <span className="text-xs text-neutral-600 font-serif italic">"{HELMI_HERO.quote.slice(0, 64)}..."</span>
        </div>
        <div className="p-3 bg-white rounded-2xl border border-neutral-200 shadow-2xs flex flex-col justify-center">
          <span className="font-heading font-black text-xl text-[#111111]">{HELMI_HERO.experienceYears}</span>
          <span className="text-[10px] text-neutral-500 font-medium">in Brand & Marketing Experince</span>
        </div>
      </div>

    </section>
  );
};
