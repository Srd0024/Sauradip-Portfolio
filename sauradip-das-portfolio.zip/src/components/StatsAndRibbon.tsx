import React from 'react';
import { HELMI_STATS, HELMI_SKILLS_RIBBON } from '../data/portfolioData';

export const StatsAndRibbon: React.FC = () => {
  return (
    <div className="w-full z-20">
      {/* 1. Full-Width Black Horizontal Stats Strip */}
      <section id="stats-strip" className="w-full bg-[#111111] text-white py-8 sm:py-10 px-4 sm:px-8 border-y border-neutral-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 overflow-x-auto no-scrollbar">
          
          {/* Small "d" logo mark on left */}
          <div className="hidden md:flex items-center text-neutral-400 font-serif text-lg font-bold pr-4 select-none">
            d
          </div>

          {/* 50M+ achieving in sales */}
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left shrink-0">
            <span className="font-heading font-black text-3xl sm:text-4xl md:text-5xl tracking-tight text-white">
              50M+
            </span>
            <span className="text-[11px] sm:text-xs text-neutral-300 font-medium mt-0.5">
              achieving in sales
            </span>
          </div>

          {/* Orange Sunburst Star Icon */}
          <div className="shrink-0 px-2">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6 sm:w-8 sm:h-8 text-[#F5A461]">
              <path d="M12 2l2.4 5.2L20 8l-4 4.4 1 5.6-5-3-5 3 1-5.6-4-4.4 5.6-.8L12 2z"/>
            </svg>
          </div>

          {/* 2+ Years Experience */}
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left shrink-0">
            <span className="font-heading font-black text-3xl sm:text-4xl md:text-5xl tracking-tight text-white">
              2+
            </span>
            <span className="text-[11px] sm:text-xs text-neutral-300 font-medium mt-0.5">
              Years Experience
            </span>
          </div>

          {/* 11+ Projects Done */}
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left shrink-0">
            <span className="font-heading font-black text-3xl sm:text-4xl md:text-5xl tracking-tight text-white">
              11+
            </span>
            <span className="text-[11px] sm:text-xs text-neutral-300 font-medium mt-0.5">
              Projects Done
            </span>
          </div>

          {/* 6+ Helped brands */}
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left shrink-0">
            <span className="font-heading font-black text-3xl sm:text-4xl md:text-5xl tracking-tight text-white">
              6+
            </span>
            <span className="text-[11px] sm:text-xs text-neutral-300 font-medium mt-0.5">
              Helped brands
            </span>
          </div>

          {/* 3+ People Recommend Me */}
          <div className="flex flex-col items-center sm:items-start text-center sm:text-left shrink-0">
            <span className="font-heading font-black text-3xl sm:text-4xl md:text-5xl tracking-tight text-white">
              3+
            </span>
            <span className="text-[11px] sm:text-xs text-neutral-300 font-medium mt-0.5">
              People Recomen...
            </span>
          </div>

        </div>
      </section>

      {/* 2. Skills Ribbon / Marquee: White band with orange star glyphs */}
      <div className="w-full bg-[#FAF8F5] py-4 border-b border-neutral-300 overflow-hidden shadow-2xs">
        <div className="animate-marquee flex items-center whitespace-nowrap">
          {[...HELMI_SKILLS_RIBBON, ...HELMI_SKILLS_RIBBON, ...HELMI_SKILLS_RIBBON].map((item, idx) => (
            <div key={idx} className="flex items-center gap-4 mx-4 text-base sm:text-lg font-heading font-extrabold text-[#111111]">
              <span>{item}</span>
              <span className="text-[#F5A461] text-base inline-block">✦</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
